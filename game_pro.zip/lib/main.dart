import 'package:flutter/material.dart';
import 'welcome.dart';

void main() => runApp(const MaterialApp(
      home: welcome(),
      debugShowCheckedModeBanner: false,
    ));
