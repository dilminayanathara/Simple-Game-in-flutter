import 'package:flutter/material.dart';
import 'dart:math';

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  int value = 10;
  int umark = 0;
  int mmark = 0;
  int round = 1;
  Random random = Random();
  int machineValue = 0;
  List<String> images = [
    "image/paper.png",
    "image/rock.png",
    "image/sissor.png",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffbe60),
      appBar: AppBar(
        backgroundColor: Colors.orange,
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Round: $round",
              style: TextStyle(fontSize: 20),
            ),
            InkWell(
              onTap: () {
                resetGame();
              },
              child: Container(
                padding: EdgeInsets.all(8), // Adds spacing around the icon
                decoration: BoxDecoration(
                  color: Colors.white, // Background color
                  shape: BoxShape.circle, // Makes it circular
                ),
                child: Icon(
                  Icons.restart_alt_rounded,
                  size: 25, // Increases icon size
                  color: Colors.redAccent, // Changes icon color
                ),
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Color(0xffef4b82),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "Your Score: $umark",
                    style: TextStyle(fontSize: 15, color: Colors.white),
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Color(0xffef4b82),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    "Machine Score: $mmark",
                    style: TextStyle(fontSize: 15, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 200,
            width: 500,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Player choice",
                    style: TextStyle(fontSize: 20, color: Colors.black),
                  ),
                  value == 10
                      ? const Text("Waiting...")
                      : Image.asset(
                          images[machineValue],
                          height: 100,
                          width: 100,
                        ),
                ],
              ),
            ),
          ),
          Container(
            height: 5,
            width: double.infinity,
            color: Color(0xffef4b82),
          ),
          Container(
            height: 150,
            width: 500,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Your choice",
                    style: TextStyle(fontSize: 20, color: Colors.black),
                  ),
                  value == 10
                      ? Text("Select a choice")
                      : Image.asset(
                          images[value],
                          height: 100,
                          width: 100,
                        ),
                ],
              ),
            ),
          ),
          const Spacer(),
          Container(
            height: 80,
            decoration: BoxDecoration(
              color: Color(0xffef4b82),
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    child: Image.asset(images[0], height: 40),
                    onTap: () {
                      setState(() {
                        value = 0;
                        checkScore();
                      });
                    },
                  ),
                  SizedBox(width: 5),
                  InkWell(
                    child: Image.asset(images[1], height: 40),
                    onTap: () {
                      setState(() {
                        value = 1;
                        checkScore();
                      });
                    },
                  ),
                  SizedBox(width: 5),
                  InkWell(
                    child: Image.asset(images[2], height: 40),
                    onTap: () {
                      setState(() {
                        value = 2;
                        checkScore();
                      });
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void checkScore() {
    machineValue = random.nextInt(3); // Generate a machine choice
    String message = "It's a Tie!";

    if (machineValue == value) {
      message = "It's a Tie!";
    } else if ((value == 0 && machineValue == 1) ||
        (value == 1 && machineValue == 2) ||
        (value == 2 && machineValue == 0)) {
      umark += 10;
      message = "You Win This Round! 🎉";
    } else {
      mmark += 10;
      message = "You Lose This Round! 😢";
    }

    // If it's the last round (5 rounds completed)
    if (round == 5) {
      Future.delayed(Duration(seconds: 1), () {
        showFinalResult();
      });
    } else {
      Future.delayed(Duration(seconds: 1), () {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Round $round Result"),
              content: Text(message, style: TextStyle(fontSize: 20)),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    setState(() {
                      round += 1;
                      value = 10;
                      machineValue = 0;
                    });
                  },
                  child: Text("Next Round"),
                ),
              ],
            );
          },
        );
      }); // Show round result
    }
  }

  void showFinalResult() {
    String finalMessage = umark > mmark
        ? "Congratulations! You Won 🎉"
        : (umark == mmark ? "It's a Draw! ⚖" : "You Lost! Try Again 😢");

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Game Finished"),
          content: Text(finalMessage, style: const TextStyle(fontSize: 20)),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                resetGame(); // Reset the game
              },
              child: const Text("Play Again"),
            ),
          ],
        );
      },
    );
  }

  void resetGame() {
    setState(() {
      round = 1;
      umark = 0;
      mmark = 0;
      value = 10;
      machineValue = 0;
    });
  }
}
