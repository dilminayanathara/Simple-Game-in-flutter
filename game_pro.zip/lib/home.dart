import 'package:flutter/material.dart';
import 'result.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffbe60),
      appBar: AppBar(
        title: const Text(
          "Rock, Paper, Scissors",
          style: TextStyle(color: Color(0xff403737)),
        ),
        backgroundColor: Colors.orange,
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xffef4b82),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => const GamePage()));
              },
              child: const Text(
                "Play",
                style: TextStyle(fontSize: 15),
              ),
            ),
            const SizedBox(height: 20), // Adds space between buttons
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xffef4b82),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                // TODO: Navigate to the Instructions Page
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const InstructionsPage()));
              },
              child: const Text(
                "See Instructions",
                style: TextStyle(fontSize: 15),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const BottomAppBar(
        color: Colors.orange,
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Text(
            "© 2025 Rock Paper Scissors Game",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              color: Color(0xff40373),
            ),
          ),
        ),
      ),
    );
  }
}

// Create an Instructions Page
class InstructionsPage extends StatelessWidget {
  const InstructionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffbe60),
      appBar: AppBar(
        title: const Text("Instructions"),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: "✅ The game includes 5 rounds.\n\n",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffe30e78)),
                ),
                TextSpan(
                  text: "How to Play Rock, Paper, Scissors:\n",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline),
                ),
                TextSpan(
                  text: "1️. Rock beats Scissors ✊✂️\n",
                  style: TextStyle(fontSize: 16),
                ),
                TextSpan(
                  text: "2️.Scissors beats Paper ✂️📄\n",
                  style: TextStyle(fontSize: 16),
                ),
                TextSpan(
                  text: "3️. Paper beats Rock 📄✊\n\n",
                  style: TextStyle(fontSize: 16),
                ),
                TextSpan(
                  text: "🎯 Select your choice and try to win!",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xffe30e78)),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xffef4b82),
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const GamePage()));
            },
            child: const Text(
              "Play",
              style: TextStyle(fontSize: 15),
            ),
          ),
        ],
      ),
    );
  }
}
