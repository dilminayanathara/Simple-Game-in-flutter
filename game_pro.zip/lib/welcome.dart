import 'package:flutter/material.dart';
import 'home.dart';

class welcome extends StatefulWidget {
  const welcome({super.key});
  _welcomeState createState() => _welcomeState();
}

class _welcomeState extends State<welcome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffbe60),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image(
              image: AssetImage('image/logo.jpg'),
              width: 200,
              height: 200,
            ),
          ),
          SizedBox(
            height: 100,
          ),
          Center(
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xffef4b82),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(150, 50), // Width: 150, Height: 50
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 15), // Extra padding
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Homepage()));
                  },
                  child: Text(
                    "Start",
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  ))),
        ],
      ),
    );
  }
}
